package com.gowthamX.constructHub.features.signin;

import com.gowthamX.constructHub.data.dto.User;
import com.gowthamX.constructHub.features.home.HomeView;
import com.gowthamX.constructHub.features.signup.SignUpView;
import com.gowthamX.constructHub.util.ConsoleInput;

import java.util.Scanner;

public class SignInView {

    private final SignInModel signInModel;
    private final Scanner scanner;
    private boolean authenticated;

    public SignInView() {
        this.signInModel = new SignInModel(this);
        this.scanner = ConsoleInput.getScanner();
        this.authenticated = false;
    }

    public void init() {
        System.out.println();
        System.out.println("Construction Site Management System");
        System.out.println("Sign in to ConstructHub");
        while (!authenticated) {
            promptAndAuthenticate();
            if (authenticated) return;
            if (!promptPostFailureAction()) return;
        }
    }

    private void promptAndAuthenticate() {
        System.out.print("  Username : ");
        String username = scanner.nextLine();
        System.out.print("  Password : ");
        String password = scanner.nextLine();
        signInModel.authenticate(username==null?null:username.trim(),password);
    }

    private boolean promptPostFailureAction() {
        while (true) {
            System.out.println();
            System.out.println("  1. Retry");
            System.out.println("  2. Exit");
            System.out.print("  Choose an option: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    return true;
                case "2":
                    System.out.println("  Thank you for!");
                    System.exit(0);
                    return false;
                default:
                    System.out.println("  Invalid option. Please try again.");
            }
        }
    }

    void onSignInSuccessful(User user) {
        authenticated = true;
        System.out.println("  Welcome, " + user.getName() + "  [" + user.getRole() + "]");
        new HomeView(user).init();
    }

    void onSignInFailed(String message) {
        System.out.println("  ERROR: " + message);
    }
}
